package tetris;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.SwingWorker;
import javax.swing.UIManager;

/**
 *
 * @author 23162287
 */
public class Carregamento extends javax.swing.JFrame {

    

    public Carregamento() {
          // Defina o tamanho do JFrame para ser igual ao tamanho do WindowGame
        setSize(WindowGame.WIDTH, WindowGame.HEIGHT);
        initComponents();
        iniciarProgressBar();
        
 lbl_count.setBounds(-15, -25, 300, 650); // Substitua 'largura' e 'altura' pelos valores desejados

// Obtém a imagem do ImageIcon
ImageIcon icon = new javax.swing.ImageIcon(getClass().getResource("/image/carrega.png"));

// Obtém a largura e altura desejadas para a imagem
int novaLargura = 300; // Substitua pelo valor desejado
int novaAltura = 650; // Substitua pelo valor desejado

// Redimensiona a imagem para a nova largura e altura
Image imagemRedimensionada = icon.getImage().getScaledInstance(novaLargura, novaAltura, java.awt.Image.SCALE_SMOOTH);

// Configura a imagem redimensionada no JLabel
lbl_count.setIcon(new ImageIcon(imagemRedimensionada));
    }

    private void iniciarProgressBar() {
    // Cria um novo SwingWorker para realizar a tarefa em segundo plano
    SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
        @Override
        // Este método é executado em uma thread separada em segundo plano
        protected Void doInBackground() throws Exception {
            try {
                // Configura a cor "Orange" no UIManager
                UIManager.put("Orange", new Color(255, 144, 0));
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Loop que itera de 1 a 100
            for (int i = 1; i <= 100; i++) {
                // Pausa a thread por 30 milissegundos (atualiza a cada 30ms)
                Thread.sleep(30);
                // Publica o valor 'i' para o método process()
                publish(i);
            }
            return null;
        }

        @Override
        // Este método é chamado quando valores são publicados a partir de doInBackground()
        protected void process(java.util.List<Integer> chunks) {
            // Obtém o valor mais recente publicado
            int progressValue = chunks.get(chunks.size() - 1);
            // Define o texto do rótulo 'lbl_count' para exibir o valor da barra de progresso
            lbl_count.setText(progressValue + " %");
            // Define o valor da barra de progresso 'jProgressBar1'
            barrap.setValue(progressValue);
        }

        @Override
        // Este método é chamado quando doInBackground() é concluído
        protected void done() {
            // Fecha a janela atual
            dispose();
            // Abre uma nova janela da classe 'PaginaStart'
            new Login().setVisible(true);
        }
    };

    // Inicia a execução do SwingWorker em segundo plano
    worker.execute();
}

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        barrap = new javax.swing.JProgressBar();
        lbl_count = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);
        jPanel1.add(barrap);
        barrap.setBounds(80, 430, 90, 14);
        jPanel1.add(lbl_count);
        lbl_count.setBounds(-10, -20, 270, 600);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 567, Short.MAX_VALUE)
                .addGap(3, 3, 3))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carregamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carregamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carregamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carregamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Carregamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barrap;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbl_count;
    // End of variables declaration//GEN-END:variables

}
