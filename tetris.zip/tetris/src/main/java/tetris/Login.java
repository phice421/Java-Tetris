package tetris;


import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import inicio.conecta.Entrada;
import inicio.conecta.conectaMongo;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Login extends javax.swing.JFrame {
    


    private MongoClient mongoClient;
    private MongoCollection<Document> collection;

    public Login() {
        initComponents();
        // Defina a cor de fundo dos campos de texto para transparente
        Cname.setBackground(new java.awt.Color(0, 0, 0, 1));
        Csexo.setBackground(new java.awt.Color(0, 0, 0, 1));
        Csexo.setBackground(new java.awt.Color(0, 0, 0, 1));
        Csexo.setBackground(new java.awt.Color(0, 0, 0, 1));
        name.setBackground(new java.awt.Color(0, 0, 0, 1));
        pass.setBackground(new java.awt.Color(0, 0, 0, 1));
        Cemail1.setBackground(new java.awt.Color(0, 0, 0, 1));
        Cpass1.setBackground(new java.awt.Color(0, 0, 0, 1));
        // Inicialize a conexão com o MongoDB
        mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase database = mongoClient.getDatabase("seuBancoDeDados");
        collection = database.getCollection("suaColecao");
        
// ...
jLabel1.setIcon(new javax.swing.ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/image/cadastro.png")).getImage().getScaledInstance(260, 610, java.awt.Image.SCALE_SMOOTH)));



jLabel2.setIcon(new javax.swing.ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/image/login.png")).getImage().getScaledInstance(260, 610, java.awt.Image.SCALE_SMOOTH)));
jLabel2.setIcon(new javax.swing.ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/image/login.png")).getImage().getScaledInstance(260, 610, java.awt.Image.SCALE_SMOOTH)));
jPanel1.setLayout(null);  // Mantenha o layout como nulo para posicionamento absoluto

// Exemplo com BorderLayout
jPanel1.setLayout(new BorderLayout());

name.setPreferredSize(new Dimension(140, 20));
pass.setPreferredSize(new Dimension(140, 20));

name.setBounds(50, 350, 160, 30);
pass.setBounds(50, 410, 160, 30);

name.setBackground(new java.awt.Color(0, 0, 0, 1));
pass.setBackground(new java.awt.Color(0, 0, 0, 1));

pack();


// ...

        
    }

    public Entrada createUser() {
        Entrada user = new Entrada();
        user.setName(Cname.getText());
        user.setPassword(Csexo.getText());
        user.setEmail(Csexo.getText()); // Adicione o campo "email"
        user.setSexo(Csexo.getText()); // Adicione o campo "sexo"
        return user;
    }

    public Document createDocument(Entrada user) {
        Document docBuilder = new Document();
        docBuilder.append("name", user.getName());
        docBuilder.append("pass", user.getPass());
        docBuilder.append("email", user.getEmail()); // Adicione o campo "email"
        docBuilder.append("sexo", user.getSexo()); // Adicione o campo "sexo"
        return docBuilder;
    }

    // Método para inserir dados no MongoDB quando o botão "Cadastrar" é pressionado
//    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {
//        Entrada user = createUser();
//        Document doc = createDocument(user);
//
//        try {
//            collection.insertOne(doc); // Insere o documento no MongoDB
//            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso!");
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Erro ao inserir dados no MongoDB: " + e.getMessage());
//        }
//    }

    // Método para buscar dados no MongoDB quando o botão "Entrar" é pressionado
//    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {
//        // Obtém o nome e a senha inseridos pelo usuário
//        String Name = name.getText();
//        String Pass = pass.getText();
//
//        // Realiza a busca no MongoDB com base no nome inserido
//        conectaMongo conn = new conectaMongo();
//        conn.findValuesName(Name);
//        conn.findValuesPass(Pass); // Suponho que você tenha um método "findValuesPass" na classe "conectaMongo".
//    }

    // Outros métodos e código da interface gráfica aqui...

    // Código gerado pelo NetBeans, não modifique
//    private void initComponents() {
//        // ...
//        
//        entrar = new javax.swing.JButton();
//        cadastrar = new javax.swing.JButton();
//        Cemail1 = new javax.swing.JTextField();
//        Cname = new javax.swing.JTextField();
//        Cpass1 = new javax.swing.JTextField();
//        Csexo = new javax.swing.JTextField();
//
//        // ...
//        
//        entrar.setText("Entrar");
//        entrar.addActionListener(new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                entrarActionPerformed(evt);
//            }
//        });
//
//        cadastrar.setText("Cadastrar");
//        cadastrar.addActionListener(new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                cadastrarActionPerformed(evt);
//            }
//        });
//
//        // ...
//        
//        pack();
//    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        entrar = new javax.swing.JButton();
        Cpass1 = new javax.swing.JPasswordField();
        pass = new javax.swing.JPasswordField();
        cadastrar = new javax.swing.JButton();
        Csexo = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        Cemail1 = new javax.swing.JTextField();
        Cname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        entrar.setText("Entrar");
        entrar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        jPanel1.add(entrar);
        entrar.setBounds(70, 460, 120, 20);

        Cpass1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Cpass1.setBorder(null);
        Cpass1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cpass1ActionPerformed(evt);
            }
        });
        jPanel1.add(Cpass1);
        Cpass1.setBounds(310, 320, 150, 20);

        pass.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pass.setBorder(null);
        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        jPanel1.add(pass);
        pass.setBounds(50, 380, 150, 20);

        cadastrar.setText("Cadastrar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(cadastrar);
        cadastrar.setBounds(330, 460, 110, 20);

        Csexo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Csexo.setBorder(null);
        Csexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CsexoActionPerformed(evt);
            }
        });
        jPanel1.add(Csexo);
        Csexo.setBounds(310, 390, 140, 20);

        name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name.setBorder(null);
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        jPanel1.add(name);
        name.setBounds(50, 430, 140, 20);

        Cemail1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Cemail1.setBorder(null);
        Cemail1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cemail1ActionPerformed(evt);
            }
        });
        jPanel1.add(Cemail1);
        Cemail1.setBounds(310, 260, 140, 20);

        Cname.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Cname.setBorder(null);
        Cname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CnameActionPerformed(evt);
            }
        });
        jPanel1.add(Cname);
        Cname.setBounds(310, 200, 140, 20);
        jPanel1.add(jLabel2);
        jLabel2.setBounds(0, -10, 260, 610);
        jPanel1.add(jLabel1);
        jLabel1.setBounds(260, -20, 440, 600);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
     // MONGO NOME
        
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("turmaB");
        MongoCollection<Document> docs = db.getCollection("turmaB");
        
         String Name = name.getText();
         String Pass = pass.getText();// Obtém o nome inserido pelo usuário
         
         

    // Realiza a busca no MongoDB com base no nome inserido
    conectaMongo conn = new conectaMongo();
    conn.findValuesName(Name); 
    conn.findValuesName(Pass);// Suponho que você tenha um método "findValuesName" na classe "conectaMongo" para realizar a busca.

      dispose();
        SwingUtilities.invokeLater(() -> {
            try {
                new WindowGame().setVisible(true);
            } catch (IOException ex) {
                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            }
    });
        
    }//GEN-LAST:event_entrarActionPerformed

  
    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
     // Botão "Salvar" (ou outro nome que você queira dar)

    // Obtém os valores dos campos
    String Name = Cname.getText();
    String Password = Cpass1.getText();
    String Email = Cemail1.getText();
    String Sexo = Csexo.getText(); // Certifique-se de que existe um campo chamado "sexo" no seu formulário.

    // Cria uma instância de conectaMongo
    conectaMongo conn = new conectaMongo();

    // Insere os valores no banco de dados
    conn.insertValues(Name, Password, Email, Sexo);

  

    // Dentro do método onde você lida com o cadastro bem-sucedido
JOptionPane.showMessageDialog(this, "Parabéns! Seu cadastro foi realizado com sucesso.");

// Em seguida, você pode limpar os campos do formulário, se desejar
Cname.setText("");
Cpass1.setText("");
Cemail1.setText("");
Csexo.setText("");
    
    
        
    }//GEN-LAST:event_cadastrarActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void CnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CnameActionPerformed

    private void CsexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CsexoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CsexoActionPerformed

    private void Cemail1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cemail1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Cemail1ActionPerformed

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void Cpass1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cpass1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Cpass1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cemail1;
    private javax.swing.JTextField Cname;
    private javax.swing.JPasswordField Cpass1;
    private javax.swing.JTextField Csexo;
    private javax.swing.JButton cadastrar;
    private javax.swing.JButton entrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField name;
    private javax.swing.JPasswordField pass;
    // End of variables declaration//GEN-END:variables
}
