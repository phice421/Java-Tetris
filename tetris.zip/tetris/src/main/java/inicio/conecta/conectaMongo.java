package inicio.conecta;

import com.mongodb.MongoClient; 
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Scanner;
import javax.swing.JTextField;
import org.bson.Document;
import com.mongodb.client.model.Updates;
import javax.swing.JOptionPane;
import tetris.Login;
import tetris.Carregamento;

public class conectaMongo {

    
    public void getValues(){
         System.out.println("Digite o código a buscar no banco:");
        Scanner sc = new Scanner(System.in);
//        int code = sc.nextInt();
//        System.out.println("Código: " + code);
        MongoClient mongo = new MongoClient("localhost", 27017); // direcionar caminho e porta do mongo
        MongoDatabase db = mongo.getDatabase("turmaB"); 
        MongoCollection<Document> docs = db.getCollection("turmaB");
       for (Document doc : docs.find()){
           System.out.println("item "+ doc);
       }
       
        System.out.println("getValues ok");
       
    
    }
    
//   public Entrada findValuesPassword(String password) {
//        System.out.println("Método findName()");
//        MongoClient mongo = new MongoClient("localhost", 27017);
//        MongoDatabase db = mongo.getDatabase("turmaB");
//        MongoCollection<Document> docs = db.getCollection("turmaB");
//      Document userDocument = docs.find(Filters.eq("password", password)).first(); // Encontra o primeiro documento com a senha
//
//    if (userDocument != null) {
//        Entrada entrada = new Entrada();
//        entrada.setName(userDocument.getString("name")); // Supondo que o nome esteja armazenado como uma String no documento
//        // Configure outros atributos do objeto Entrada, se necessário
//
//        System.out.println("Senha encontrada - Nome: " + entrada.getName());
//        new Carregamento().setVisible(true);
//        return entrada;
//    } else {
//        // Se a senha não foi encontrada, exiba um JOptionPane
//        JOptionPane.showMessageDialog(null, "Senha não encontrada", "Aviso", JOptionPane.WARNING_MESSAGE);
//        new Load().setVisible(true);
//        return null;
//    }}
    
    public void findValuesName(String name){
        System.out.println("Método findName()");
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("turmaB");
        MongoCollection<Document> docs = db.getCollection("turmaB");
        
        for (Document doc : docs.find(Filters.eq("name", name))){
            System.out.println("achou pelo nome: "+doc);
        }
        System.out.println("findName() - finalizou");
    }
    
    public void findValuesPass(String pass){
        System.out.println("Método findPass()");
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("turmaB");
        MongoCollection<Document> docs = db.getCollection("turmaB");
        
        for (Document doc : docs.find(Filters.eq("pass", pass))){
            System.out.println("achou pelo nome: "+doc);
        }
        System.out.println("findName() - finalizou");
    }
    
    
    public void insertValues(String Cname,String Cpass, String Csexo, String Cemail){
        System.out.println("método insertValues()");
        MongoClient mongo = new MongoClient("localhost", 27017); // direcionar caminho e porta do mongo
        MongoDatabase db = mongo.getDatabase("turmaB"); 
        MongoCollection<Document> docs = db.getCollection("turmaB");
        Entrada user = createUser(Cname, Cpass);
        Document doc = createDocument(user);
        docs.insertOne(doc);
        getValues();
        System.out.println("insertValues ok");
        
    
    }
    
  public Entrada createUser(String name, String password) {
        //esse método deve ser uma entrada 
        //externa (interface, scanner ou JOptionPanel
        Entrada u = new Entrada();
        u.setPassword(password);
        u.setName(name);
       
        return u;
    }
    
       public Document createDocument(Entrada user) {
        Document docBuilder = new Document();
        docBuilder.append("name", user.getName());
        docBuilder.append("password", user.getPass());
        
       
        return docBuilder;
    }

}
